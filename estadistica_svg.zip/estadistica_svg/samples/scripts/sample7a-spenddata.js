 var app = angular.module("TFGPOC", ['nvd3ChartDirectives']);

 
		
// Pie Chart
function pieChartCtrl($scope){
            $scope.pieChartData = [
                {
                    key: "DERECHOS R.",
                    y: 8                },
                {
                    key: "FEMINICIDA",
                    y: 58
                },
                {
                    key: "FISICA",
                    y: 3977
                },
                {
                    key: "PSICOLOGICA",
                    y: 35226
                },
                {
                    key: "SEXUAL",
                    y: 13846
                }
                
              
            ];
            $scope.colours = ["#2b00ff","#902da5","#fffd00","#ff8b00","#ff1a00"];
            $scope.xFunction = function(){
                return function(d) {
                    return d.key;
                };
            }
            $scope.yFunction = function(){
                return function(d) {
                    return d.y;
                };
            }

            $scope.descriptionFunction = function(){
                return function(d){
                    return d.key;
                }
            }
        }
		
// Bar Chart
 function barChartCtrl($scope){
            $scope.barChartData = [
                {
                    key: "Cumulative Return",
                    values: [
                        ["DERECHOS R.", 8 ],
                        ["FEMINICIDA" , 58 ],
                        ["FISICA" , 3977 ],
                        ["PSICOLOGICA" , 35226 ],
                        ["SEXUAL" , 13846 ]
                       
                    ]
                }
            ];
            $scope.colours = ["#2b00ff","#902da5","#fffd00","#ff8b00","#ff1a00"]

        }
		

